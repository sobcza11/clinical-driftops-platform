# Fairness Audit

**Group column:** `gender`

**Overall positive rate:** 0.0389

| group   |   n |   positive_rate |   disparity |
|:--------|----:|----------------:|------------:|
| F       | 161 |       0.0186335 |  -0.0202266 |
| M       | 225 |       0.0533333 |   0.0144732 |
